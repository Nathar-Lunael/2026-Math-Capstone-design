﻿// Doulble-and-Add 알고리즘 사용하는 secp256k1 상의 ECC코드.cpp 

#include <stdio.h>
#include <stdint.h>
#include <intrin.h> // MSVC 전용 내장 함수 (_umul128, _addcarry_u64 등)를 위한 헤더

// ====================================================================
// [0. 전역 상수 및 구조체 정의 (secp256k1)]
// ====================================================================

const uint64_t P[4] = {                                         // P[4] : secp256k1의 소수 p = 2^256 - 2^32 - 2^9 - 2^8 - 2^7 - 2^6 - 2^4 - 1 = 2^256 - 2^32 - 977. 이를 16진수로 변환하여 64비트 리틀 엔디안(Little-endian) 배열로 저장.
    0xFFFFFFFEFFFFFC2FULL,                                      // [0] 하위 64비트 (2^64 - 2^32 - 977)
    0xFFFFFFFFFFFFFFFFULL,                                      // [1]
    0xFFFFFFFFFFFFFFFFULL,                                      // [2]
    0xFFFFFFFFFFFFFFFFULL                                       // [3] 상위 64비트
};
const uint64_t SECP_C = 0x1000003D1ULL;                         // SECP_C : 모듈러 리덕션(Reduction)을 위한 고속 보정 상수. 수학적 의미: p = 2^256 - c 형태를 가질 때, 2^256 ≡ c (mod p) 가 성립. 즉, 256비트를 넘어가는 오버플로우가 발생했을 때, 초과한 값에 c를 곱해서 하위 비트에 더해주면 나눗셈 없이 매우 빠르게 mod p 연산을 수행할 수 있음. 여기서 c = 2^32 + 977 = 4294968273
const uint64_t B_VAL[4] = { 7, 0, 0, 0 };                       // B_VAL[4] : 타원 곡선 방정식의 계수 (Curve Parameters). secp256k1 곡선 방정식: y^2 = x^3 + ax + b (단, a = 0, b = 7). a가 0이기 때문에 A_VAL 상수는 아예 필요하지 않으며, B_VAL 상수만 정의합니다.

//다중 정밀도 연산 및 타원곡선 공식에 자주 사용되는 기본 정수 상수들
const uint64_t ZERO[4] = { 0, 0, 0, 0 };
const uint64_t ONE[4] = { 1, 0, 0, 0 };
const uint64_t TWO[4] = { 2, 0, 0, 0 };
const uint64_t THREE[4] = { 3, 0, 0, 0 };
const uint64_t FOUR[4] = { 4, 0, 0, 0 };                        // 야코비안 연산에서 필요
const uint64_t EIGHT[4] = { 8, 0, 0, 0 };                       // 야코비안 연산에서 필요

// --------------------------------------------------------------------
// [구조체 정의]
// --------------------------------------------------------------------


typedef struct {                                 // AffinPoint 구조체 : 아핀 좌표계 점 (입력값 및 최종 출력용). 2차원 평면 위의 실제 좌표 (x, y)를 표현합니다.
    uint64_t X[4];
    uint64_t Y[4];
    int is_infty;                                // 1이면 무한원점(항등원 O), 0이면 유효한 점
} AffinePoint;

typedef struct {                                 // JacobianPoint 구조체 : 야코비안(Jacobian) 사영 좌표계 점 (고속 내부 연산용). 3차원 공간의 좌표 (X, Y, Z)를 표현합니다. 아핀 좌표와의 관계: x = X / Z^2, y = Y / Z^3. 점 연산 과정에서 역원(나눗셈) 연산을 회피하기 위해 사용함.
    uint64_t X[4];
    uint64_t Y[4];
    uint64_t Z[4];
    int is_infty;
} JacobianPoint;

// ====================================================================
// [1. 다중 정밀도 연산 함수 (Multi-Precision Basics)]
// ====================================================================

/**
 * @brief 256비트 정수 a가 소수 P보다 크거나 같은지 판별 (a >= P)
 * @details 모듈러 덧셈 후 오버플로우가 발생했는지(P를 빼야 하는지) 판별할 때 사용됩니다.
 * 리틀 엔디안(Little-Endian) 방식이므로 가장 높은 자릿수(인덱스 3)부터 비교합니다.
 */
int geq_P(const uint64_t* a) {
    for (int i = 3; i >= 0; i--) {
        if (a[i] > P[i]) return 1; // a가 더 큼
        if (a[i] < P[i]) return 0; // a가 더 작음
    }
    return 1; // 모든 자릿수가 완전히 동일함 (a == P)
}

/**
 * @brief 두 256비트 정수가 완벽히 동일한지 판별 (a == b)
 * @details 타원 곡선 점 덧셈 연산에서 두 점이 같은지(point_double로 우회해야 하는지)
 * 확인하는 엣지 케이스 방어 로직에 사용됩니다.
 */
int is_equal(const uint64_t* a, const uint64_t* b) {
    for (int i = 0; i < 4; i++) {
        if (a[i] != b[i]) return 0;
    }
    return 1;
}

/**
 * @brief 256비트 정수가 0인지 판별 (a == 0)
 * @details 분모가 0이 되어 역원 연산이 붕괴되는 것을 막거나,
 * 무한원점(Infinity) 도달 여부를 확인할 때 사용됩니다.
 */
int is_zero(const uint64_t* a) {
    for (int i = 0; i < 4; i++) {
        if (a[i] != 0) return 0;
    }
    return 1;
}

// ====================================================================
// [2. 모듈러 연산 함수]
// ====================================================================

/**
 * @brief 모듈러 덧셈: res = (a + b) mod p
 * @details 256비트 덧셈 수행 후, 결과가 P 이상이면 P를 빼서 모듈러 보정을 수행합니다.
 */
void mod_add(uint64_t* res, const uint64_t* a, const uint64_t* b) {
    uint64_t temp[4];
    uint8_t carry = 0;

    // 1. 256비트 덧셈
    for (int i = 0; i < 4; i++) {
        carry = _addcarry_u64(carry, a[i], b[i], &temp[i]);
    }

    // 2. 모듈러 리덕션: temp가 P보다 크거나 같으면 P를 뺌
    while (geq_P(temp)) {
        uint8_t borrow = 0;
        for (int i = 0; i < 4; i++) {
            borrow = _subborrow_u64(borrow, temp[i], P[i], &temp[i]);
        }
    }
    for (int i = 0; i < 4; i++) res[i] = temp[i];
}

/**
 * @brief 모듈러 뺄셈: res = (a - b) mod p
 * @details 256비트 뺄셈 수행 후, 언더플로우가 발생하면 P를 더해 양수 모듈러로 복원합니다.
 */
void mod_sub(uint64_t* res, const uint64_t* a, const uint64_t* b) {
    uint64_t temp[4];
    uint8_t borrow = 0;

    // 1. 256비트 뺄셈
    for (int i = 0; i < 4; i++) {
        borrow = _subborrow_u64(borrow, a[i], b[i], &temp[i]);
    }

    // 2. 모듈러 복원: 언더플로우 시 P를 더함
    if (borrow) {
        uint8_t carry = 0;
        for (int i = 0; i < 4; i++) {
            carry = _addcarry_u64(carry, temp[i], P[i], &temp[i]);
        }
    }
    for (int i = 0; i < 4; i++) res[i] = temp[i];
}

/**
 * @brief 모듈러 곱셈: res = (a * b) mod p (secp256k1 전용 고속 최적화)
 * @details 512비트 스쿨북 곱셈 후, p = 2^256 - c 의 특성을 이용해
 * 상위 256비트에 c(SECP_C)를 곱하여 하위에 더하는 방식으로 리덕션을 수행합니다.
 */
void mod_mul(uint64_t* res, const uint64_t* a, const uint64_t* b) {
    uint64_t t[8] = { 0 };

    // 1단계: 256비트 * 256비트 = 512비트 곱셈 (오버플로우 완벽 차단)
    for (int i = 0; i < 4; i++) {
        uint64_t carry = 0;
        for (int j = 0; j < 4; j++) {
            uint64_t hi, lo;
            lo = _umul128(a[i], b[j], &hi);

            uint8_t c1 = _addcarry_u64(0, t[i + j], lo, &t[i + j]);
            uint8_t c2 = _addcarry_u64(0, t[i + j], carry, &t[i + j]);
            carry = hi + c1 + c2;
        }
        t[i + 4] = carry;
    }

    // 2단계: 512비트를 256비트로 쪼개기
    uint64_t H[4] = { t[4], t[5], t[6], t[7] }; // 상위 256비트
    uint64_t L[4] = { t[0], t[1], t[2], t[3] }; // 하위 256비트

    // 3단계: 상위 256비트(H)에 SECP_C를 곱함
    uint64_t hiC[5] = { 0 };
    uint64_t carryC = 0;
    for (int i = 0; i < 4; i++) {
        uint64_t hi, lo;
        lo = _umul128(H[i], SECP_C, &hi);
        uint8_t c = _addcarry_u64(0, lo, carryC, &hiC[i]);
        carryC = hi + c;
    }
    hiC[4] = carryC;

    // 4단계: H * SECP_C 결과를 하위 256비트(L)와 더함
    uint64_t L_res[4];
    uint8_t c_L = 0;
    for (int i = 0; i < 4; i++) {
        c_L = _addcarry_u64(c_L, L[i], hiC[i], &L_res[i]);
    }

    // 5단계: 위 덧셈에서 발생한 오버플로우를 잡아내어 한 번 더 SECP_C 곱셈 보정
    uint64_t over = hiC[4] + c_L;
    uint64_t temp[4];

    // 🚨 66비트 오버플로우 방지를 위해 _umul128 사용!
    uint64_t c2_hi, c2_lo;
    c2_lo = _umul128(over, SECP_C, &c2_hi);

    // 하위 64비트(c2_lo)는 인덱스 0번 배열에 더함
    uint8_t cc = _addcarry_u64(0, L_res[0], c2_lo, &temp[0]);

    // 상위 비트(c2_hi)는 발생한 올림수(cc)와 함께 인덱스 1번 배열에 더함
    cc = _addcarry_u64(cc, L_res[1], c2_hi, &temp[1]);

    // 나머지 인덱스 2, 3번 배열은 올림수(cc)만 전파
    cc = _addcarry_u64(cc, L_res[2], 0, &temp[2]);
    cc = _addcarry_u64(cc, L_res[3], 0, &temp[3]);

    // 극단적인 엣지 케이스에서의 마지막 오버플로우 보정
    if (cc) {
        cc = _addcarry_u64(0, temp[0], SECP_C, &temp[0]);
        for (int i = 1; i < 4; i++) cc = _addcarry_u64(cc, temp[i], 0, &temp[i]);
    }

    // 6단계: 최종 P 범위 내로 리덕션
    while (geq_P(temp)) {
        uint8_t br = 0;
        for (int i = 0; i < 4; i++) br = _subborrow_u64(br, temp[i], P[i], &temp[i]);
    }
    for (int i = 0; i < 4; i++) res[i] = temp[i];
}

/**
 * @brief 모듈러 역원: res = a^(-1) mod p
 * @details 페르마의 소정리 (a^(p-2) ≡ a^(-1) mod p)를 이용한 Right-to-Left 이진 거듭제곱 알고리즘.
 * 야코비안 연산이 모두 끝난 후, 아핀 좌표로 변환할 때 딱 한 번만 호출됩니다.
 */
void mod_inv(uint64_t* res, const uint64_t* a) {
    uint64_t r[4] = { 1, 0, 0, 0 };
    uint64_t base[4];
    for (int i = 0; i < 4; i++) base[i] = a[i];

    // secp256k1의 P - 2 = 2^256 - 2^32 - 979
    const uint64_t PM2[4] = {
        0xFFFFFFFEFFFFFC2DULL, 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL
    };

    for (int i = 0; i < 256; i++) {
        uint64_t bit = (PM2[i / 64] >> (i % 64)) & 1;
        if (bit) mod_mul(r, r, base);
        mod_mul(base, base, base);
    }
    for (int i = 0; i < 4; i++) res[i] = r[i];
}

// ====================================================================
// [3. 타원곡선 점 연산 (Jacobian Coordinates)]
// ====================================================================

/**
 * @brief 점 두 배 연산: res = 2 * pt (Jacobian)
 * @details 분수 연산(역원)을 피하기 위해 3차원 사영 공간에서 두 배 연산을 수행합니다.
 * secp256k1은 곡선 방정식의 a=0 이므로 연산이 더욱 최적화(M 계산 부분)됩니다.
 */
void point_double_jacobian(JacobianPoint* res, const JacobianPoint* pt) {
    // 무한원점(항등원)을 2배 하면 그대로 무한원점입니다.
    if (pt->is_infty) {
        res->is_infty = 1;
        return;
    }

    JacobianPoint out; // 포인터 앨리어싱(메모리 충돌) 방지용 임시 버퍼
    out.is_infty = 0;

    uint64_t XX[4], YY[4], YYYY[4], S[4], M[4], T[4];
    uint64_t X3[4], Y3[4], Z3[4];

    // 1. 기초 제곱 연산
    mod_mul(XX, pt->X, pt->X);         // XX = X^2
    mod_mul(YY, pt->Y, pt->Y);         // YY = Y^2
    mod_mul(YYYY, YY, YY);             // YYYY = Y^4

    // 2. S = 4 * X * Y^2 계산
    mod_mul(S, pt->X, YY);
    mod_mul(S, S, FOUR);

    // 3. M = 3 * X^2 계산 
    // (본래 M = 3*X^2 + a*Z^4 이지만, secp256k1은 a=0 이므로 뒤의 항이 소거됨)
    mod_mul(M, XX, THREE);

    // 4. 새로운 X좌표 계산: X3 = M^2 - 2*S
    mod_mul(X3, M, M);
    mod_mul(T, S, TWO);
    mod_sub(X3, X3, T);

    // 5. 새로운 Y좌표 계산: Y3 = M*(S - X3) - 8*Y^4
    mod_sub(T, S, X3);
    mod_mul(Y3, M, T);
    mod_mul(T, YYYY, EIGHT);
    mod_sub(Y3, Y3, T);

    // 6. 새로운 Z좌표 계산: Z3 = 2 * Y * Z
    mod_mul(Z3, pt->Y, pt->Z);
    mod_mul(Z3, Z3, TWO);

    // 7. 결과를 버퍼에서 출력 구조체로 복사
    for (int i = 0; i < 4; i++) {
        out.X[i] = X3[i];
        out.Y[i] = Y3[i];
        out.Z[i] = Z3[i];
    }
    *res = out;
}

/**
 * @brief 점 덧셈 연산: res = p1 + p2 (Jacobian)
 * @details 두 점의 분모(Z)를 통일하기 위해 교차 곱셈(Cross Multiplication)을 수행합니다.
 */
void point_add_jacobian(JacobianPoint* res, const JacobianPoint* p1, const JacobianPoint* p2) {
    // 어느 한쪽이 무한원점이면 다른 쪽 점을 반환합니다.
    if (p1->is_infty) { *res = *p2; return; }
    if (p2->is_infty) { *res = *p1; return; }

    JacobianPoint out; // 포인터 앨리어싱 방지용 임시 버퍼
    out.is_infty = 0;

    uint64_t Z1Z1[4], Z2Z2[4], U1[4], U2[4], S1[4], S2[4], H[4], R[4];
    uint64_t H2[4], H3[4], U1H2[4], X3[4], Y3[4], Z3[4], T[4], Z1Z2[4];

    // 1. Z의 제곱 계산
    mod_mul(Z1Z1, p1->Z, p1->Z);       // Z1^2
    mod_mul(Z2Z2, p2->Z, p2->Z);       // Z2^2

    // 2. X 좌표계 교차 곱셈: U1 = X1 * Z2^2, U2 = X2 * Z1^2
    mod_mul(U1, p1->X, Z2Z2);
    mod_mul(U2, p2->X, Z1Z1);

    // 3. Y 좌표계 교차 곱셈: S1 = Y1 * Z2^3, S2 = Y2 * Z1^3 (오류 완벽 교정 완료)
    mod_mul(T, p2->Z, Z2Z2);           // T = Z2^3
    mod_mul(S1, p1->Y, T);             // S1 = Y1 * Z2^3 

    mod_mul(T, p1->Z, Z1Z1);           // T = Z1^3
    mod_mul(S2, p2->Y, T);             // S2 = Y2 * Z1^3 

    // 4. 예외 처리: 동일한 점이거나 역원 관계인지 판별
    if (is_equal(U1, U2)) {
        if (is_equal(S1, S2)) {
            // 두 점의 좌표가 완벽히 일치하면 점 두 배 연산(point double)으로 우회
            point_double_jacobian(res, p1);
            return;
        }
        else {
            // X는 같은데 Y가 다르면 두 점을 이은 선이 수직선이므로 무한원점(Infinity) 도달
            res->is_infty = 1;
            return;
        }
    }

    // 5. 핵심 기울기 변수 유도
    mod_sub(H, U2, U1);                // H = U2 - U1
    mod_sub(R, S2, S1);                // R = S2 - S1

    mod_mul(H2, H, H);                 // H^2
    mod_mul(H3, H, H2);                // H^3
    mod_mul(U1H2, U1, H2);             // U1 * H^2

    // 6. 새로운 X좌표: X3 = R^2 - H^3 - 2 * U1 * H^2
    mod_mul(X3, R, R);
    mod_sub(X3, X3, H3);
    mod_mul(T, U1H2, TWO);
    mod_sub(X3, X3, T);

    // 7. 새로운 Y좌표: Y3 = R * (U1 * H^2 - X3) - S1 * H^3
    mod_sub(T, U1H2, X3);
    mod_mul(Y3, R, T);
    mod_mul(T, S1, H3);
    mod_sub(Y3, Y3, T);

    // 8. 새로운 Z좌표: Z3 = Z1 * Z2 * H
    mod_mul(Z1Z2, p1->Z, p2->Z);
    mod_mul(Z3, Z1Z2, H);

    // 9. 결과를 버퍼에서 출력 구조체로 복사
    for (int i = 0; i < 4; i++) {
        out.X[i] = X3[i];
        out.Y[i] = Y3[i];
        out.Z[i] = Z3[i];
    }
    *res = out;
}

// ====================================================================
// [4. Double-and-Add 알고리즘]
// ====================================================================

/**
 * @brief 스칼라 곱셈: res = scalar * base_point (Jacobian 내부 연산)
 * @details Left-to-Right Double-and-Add 방식을 사용하여 256비트 스칼라 곱셈을 수행합니다.
 * 입력된 2차원 아핀 좌표를 3차원 야코비안 좌표로 변환하여 고속 연산 후 반환합니다.
 */
void scalar_mult_jacobian(JacobianPoint* res, const uint64_t* scalar, const AffinePoint* base_point) {

    // 1. 기준점(Affine)을 야코비안 좌표계로 매핑 (Z = 1)
    // 수학적으로 (x, y)는 야코비안 공간에서 (x, y, 1)로 표현됩니다.
    JacobianPoint P_base;
    for (int i = 0; i < 4; i++) {
        P_base.X[i] = base_point->X[i];
        P_base.Y[i] = base_point->Y[i];
        P_base.Z[i] = (i == 0) ? 1 : 0; // Z 배열은 {1, 0, 0, 0}
    }
    P_base.is_infty = base_point->is_infty;

    // 2. 누적기 Q를 항등원(무한원점)으로 초기화
    JacobianPoint Q;
    Q.is_infty = 1;

    // 3. MSB(255번 비트)부터 LSB(0번 비트)까지 메인 루프 수행
    for (int i = 255; i >= 0; i--) {

        // [Double 단계]
        // 무한원점이 아닐 때만 자신을 두 배로 만듦
        if (!Q.is_infty) {
            point_double_jacobian(&Q, &Q);
        }

        // [Add 단계]
        // 현재 비트가 1이면 기준점(P_base)을 더함
        uint64_t bit = (scalar[i / 64] >> (i % 64)) & 1;
        if (bit) {
            point_add_jacobian(&Q, &Q, &P_base);
        }
    }

    // 4. 연산이 완료된 야코비안 점 반환
    *res = Q;
}
// ====================================================================
// [5. 최종 좌표 변환]
// ====================================================================

/**
 * @brief 야코비안 좌표를 아핀 좌표로 변환: (x, y) = (X/Z^2, Y/Z^3)
 * @details 스칼라 곱셈이 끝난 후 딱 한 번 호출되어 결과를 도출합니다.
 */
void jacobian_to_affine(AffinePoint* res, const JacobianPoint* pt) {
    if (pt->is_infty) {
        res->is_infty = 1;
        return;
    }

    uint64_t z_inv[4], z_inv2[4], z_inv3[4];

    // 1. Z의 역원 계산 (Z^-1)
    mod_inv(z_inv, pt->Z);

    // 2. Z^-2 와 Z^-3 계산
    mod_mul(z_inv2, z_inv, z_inv);     // z_inv2 = Z^-2
    mod_mul(z_inv3, z_inv2, z_inv);    // z_inv3 = Z^-3

    // 3. 아핀 좌표 X, Y 계산
    mod_mul(res->X, pt->X, z_inv2);    // x = X * Z^-2
    mod_mul(res->Y, pt->Y, z_inv3);    // y = Y * Z^-3

    res->is_infty = 0;
}

// 추가 유틸리티 함수.

int is_on_curve_secp256k1(const AffinePoint* pt) {          // is on curve secp256k1 : 기준점이 정말로 타원 곡선 secp256k1 상의 점인지 검증 
    if (pt->is_infty)
        return 1;

    uint64_t x2[4], x3[4], rhs[4], lhs[4];

    mod_mul(x2, pt->X, pt->X);    // x^2
    mod_mul(x3, x2, pt->X);       // x^3

    // 우변: x^3 + 7
    mod_add(rhs, x3, B_VAL);

    // 좌변: y^2
    mod_mul(lhs, pt->Y, pt->Y);

    return is_equal(lhs, rhs);
}


void print_256(const char* label, const uint64_t* num) {    // 256비트 정수를 16진수로 출력하는 함수.
    printf("%s:\n%016llx %016llx %016llx %016llx\n", label, num[3], num[2], num[1], num[0]);
}



// ====================================================================
// [메인 함수] secp256k1 테스트 1. 가혹한 테스트 벡터
// ====================================================================

int main() {
    printf("=== secp256k1 ECC: Standard Vector Verification ===\n\n");

    // 표준 G 좌표 (정확한 64-bit Little-Endian)
    uint64_t G_X[4] = { 0x59F2815B16F81798ULL, 0x029BFCDB2DCE28D9ULL, 0x55A06295CE870B07ULL, 0x79BE667EF9DCBBACULL };
    uint64_t G_Y[4] = { 0x9C47D08FFB10D4B8ULL, 0xFD17B448A6855419ULL, 0x5DA4FBFC0E1108A8ULL, 0x483ADA7726A3C465ULL };

    typedef struct {
        uint64_t k[4];
        uint64_t expected_x[4];
        uint64_t expected_y[4];
    } TestVector;

    TestVector tests[] = {
        // [Test 1] High Entropy Random (실제 이더리움 테스트용 256비트 개인키)
        // k = 0x3289CCCBC9C65FB424A36E726C48ECB7A0F8D8E61DFDFF1DC869107978E53EC9
        {{0xC869107978E53EC9ULL, 0xA0F8D8E61DFDFF1DULL, 0x24A36E726C48ECB7ULL, 0x3289CCCBC9C65FB4ULL},
         {0xFAC3DF35AB274185ULL, 0x96473E93DD816F70ULL, 0x0A4029236452F289ULL, 0x2F3F3F37879E38EBULL},
         {0x9A8B642C819C5D65ULL, 0x066DED78C0ADC134ULL, 0x4152622D5029EF35ULL, 0x26B92294B0D2C764ULL}},

         // [Test 2] Extreme Edge Case: k = n - 1 (결과값은 수학적으로 -G가 도출되어야 함)
         // k = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364140
         {{0xBFD25E8CD0364140ULL, 0xBAAEDCE6AF48A03BULL, 0xFFFFFFFFFFFFFFFEULL, 0xFFFFFFFFFFFFFFFFULL},
          {0x59F2815B16F81798ULL, 0x029BFCDB2DCE28D9ULL, 0x55A06295CE870B07ULL, 0x79BE667EF9DCBBACULL}, // X는 G_X와 동일
          {0x63B82F6F04EF2777ULL, 0x02E84BB7597AABE6ULL, 0xA25B0403F1EEF757ULL, 0xB7C52588D95C3B9AULL}},// Y는 P - G_Y

          // [Test 3] k = 100 
          {{0x64ULL, 0x0ULL, 0x0ULL, 0x0ULL},
           {0x0221B4CEF7500F88ULL, 0x3EE306B3406A2689ULL, 0x2E174C835FB72BF5ULL, 0xED3BACE23C5E1765ULL},
           {0xFCE17AD5E335286EULL, 0x97BD17BE084895D0ULL, 0xDCDA5E8A7A1F87BFULL, 0xE57A6F571288CCFFULL}}
    };

    AffinePoint Base_Point;
    for (int i = 0; i < 4; i++) {
        Base_Point.X[i] = G_X[i];
        Base_Point.Y[i] = G_Y[i];
    }
    Base_Point.is_infty = 0;

    // 점이 곡선 위에 있는지 필수 검증! (이전 테스트에서 이 부분이 빠져 엉뚱한 값으로 연산되었습니다)
    if (!is_on_curve_secp256k1(&Base_Point)) {
        printf("[X] CRITICAL ERROR: Base point is NOT on the secp256k1 curve.\n");
        return -1;
    }

    printf("--- Generator Point (Base Point G) ---\n");
    print_256("Base X", Base_Point.X);
    print_256("Base Y", Base_Point.Y);
    printf("\n");

    for (int i = 0; i < 3; i++) {
        printf("--- Running Test Case k=%llu ---\n", tests[i].k[0]);

        JacobianPoint J_Res;
        AffinePoint A_Res;
        scalar_mult_jacobian(&J_Res, tests[i].k, &Base_Point);
        jacobian_to_affine(&A_Res, &J_Res);

        int x_match = is_equal(A_Res.X, tests[i].expected_x);
        int y_match = is_equal(A_Res.Y, tests[i].expected_y);

        print_256("Result X", A_Res.X);
        print_256("Result Y", A_Res.Y);

        if (x_match && y_match) printf("[PASS] Result matches standard.\n\n");
        else printf("[FAIL] Result does not match standard.\n\n");
    }

    return 0;
}


/*
// ====================================================================
// [메인 함수] secp256k1 테스트 2: secp256k1 표준 기준점 & ML알고리즘 디폴트 main함수의 비밀키 k.
// ====================================================================
int main() {
    printf("=== secp256k1 ECC: Custom Scalar Verification ===\n\n");

    // 1. 표준 G 좌표 (정확한 64-bit Little-Endian)
    uint64_t G_X[4] = { 0x59F2815B16F81798ULL, 0x029BFCDB2DCE28D9ULL, 0x55A06295CE870B07ULL, 0x79BE667EF9DCBBACULL };
    uint64_t G_Y[4] = { 0x9C47D08FFB10D4B8ULL, 0xFD17B448A6855419ULL, 0x5DA4FBFC0E1108A8ULL, 0x483ADA7726A3C465ULL };

    AffinePoint Base_Point;
    for (int i = 0; i < 4; i++) {
        Base_Point.X[i] = G_X[i];
        Base_Point.Y[i] = G_Y[i];
    }
    Base_Point.is_infty = 0;

    // 점이 곡선 위에 있는지 필수 검증
    if (!is_on_curve_secp256k1(&Base_Point)) {
        printf("[X] CRITICAL ERROR: Base point is NOT on the secp256k1 curve.\n");
        return -1;
    }

    printf("--- Generator Point (Base Point G) ---\n");
    print_256("Base X", Base_Point.X);
    print_256("Base Y", Base_Point.Y);
    printf("\n");

    // 2. 사용자 지정 스칼라(비밀키) 세팅
    // 값: 000000000000000000000000000000001111222233334444123456789ABCDEF0
    uint64_t custom_k[4] = {
        0x123456789ABCDEF0ULL,0x1111222233334444ULL, 0x0000000000000000ULL, 0x0000000000000000ULL };

    printf("--- Running Custom Test Case ---\n");
    print_256("Scalar (k)", custom_k);
    printf("\n");

    // 3. 스칼라 곱셈 실행
    JacobianPoint J_Res;
    AffinePoint A_Res;

    // Double-and-Add 실행 (Affine -> Jacobian 변환 포함)
    scalar_mult_jacobian(&J_Res, custom_k, &Base_Point);

    // 결과를 Affine 좌표로 변환
    jacobian_to_affine(&A_Res, &J_Res);

    // 4. 최종 결과 출력
    printf("[Result Public Key (Affine Coordinates)]\n");
    print_256("Result X", A_Res.X);
    print_256("Result Y", A_Res.Y);
    printf("\n");

    return 0;
}
*/