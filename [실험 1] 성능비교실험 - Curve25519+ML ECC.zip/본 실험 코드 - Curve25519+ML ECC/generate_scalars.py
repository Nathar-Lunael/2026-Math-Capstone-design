import secrets

NUM_SCALARS = 100
FILENAME = "test_vectors.h"

with open(FILENAME, "w") as f:
    # 헤더 가드 및 필요한 라이브러리 포함
    f.write("#ifndef TEST_VECTORS_H\n")
    f.write("#define TEST_VECTORS_H\n\n")
    f.write("#include <stdint.h>\n\n")
    
    # 2차원 배열 선언 (100개의 256비트 스칼라)
    f.write(f"const uint64_t Random_Scalars[{NUM_SCALARS}][4] = {{\n")

    for i in range(NUM_SCALARS):
        # 4개의 64비트 정수를 생성 (Little-endian 방식 배열)
        words = [secrets.randbits(64) for _ in range(4)]
        
        # C언어 포맷(0x...ULL)으로 변환
        hex_words = [f"0x{w:016X}ULL" for w in words]
        
        # 파일에 배열 원소 형태로 쓰기
        f.write(f"    {{ {hex_words[0]}, {hex_words[1]}, {hex_words[2]}, {hex_words[3]} }}")
        
        # 마지막 원소가 아니면 쉼표 추가
        if i < NUM_SCALARS - 1:
            f.write(",\n")
        else:
            f.write("\n")

    f.write("};\n\n")
    f.write("#endif // TEST_VECTORS_H\n")

print(f"[성공] {NUM_SCALARS}개의 무작위 스칼라가 '{FILENAME}' 파일에 생성되었습니다.")