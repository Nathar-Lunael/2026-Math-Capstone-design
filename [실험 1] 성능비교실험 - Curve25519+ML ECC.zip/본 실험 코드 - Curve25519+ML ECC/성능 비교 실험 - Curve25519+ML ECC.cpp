﻿// 본 실험 코드 - Curve25519+ML ECC.cpp 
// C 버전 (통계적 성능 비교 실험 자동화 버전)
// 반드시 솔루션 빌드를 Release모드로, Ctrl+F5로 빌드할 것.

#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <intrin.h> 
#include "test_vectors.h"  // 파이썬으로 자동 생성한 100개의 무작위 스칼라 헤더 포함

// ====================================================================
// [Step0 : 전역 상수 정의]
// ====================================================================

const uint64_t P[4] = { 0xFFFFFFFFFFFFFFEDULL, 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL, 0x7FFFFFFFFFFFFFFFULL };               // P[4] : p = 2^{255} - 19 값.
const uint64_t R2_MOD_P[4] = { 0x5A4, 0, 0, 0 };                                                                                   // R2_MOD_P[4] : R^2 (mod p) where R = 2^{256}
const uint64_t ONE[4] = { 1, 0, 0, 0 };                                                                                             // ONE[4] : Fp의 곱셈의 항등원 1
const uint64_t ONE_MONT[4] = { 38, 0, 0, 0 };                                                                                      // ONE_MONT[4]: 몽고메리 공간의 곱셈의 항등원 1*R (mod p)
const uint64_t P_MINUS_2[4] = { 0xFFFFFFFFFFFFFFEBULL, 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL, 0x7FFFFFFFFFFFFFFFULL };       // P_MINUS_2[4] : p-2의 값.
const uint64_t A24_MONT[4] = { 4623308, 0, 0, 0 };                                                                                 // A24_MONT[4] : (A+2)/4 * R (mod p)
const uint64_t M0 = 9708812670373448219ULL;                                                                                        // p에 대한 매직넘버 M0 := -p^{-1} (mod R)

typedef struct ProjPoint {
    uint64_t X[4];                                                                     // 사영좌표계의 점의 X좌표의 몽고메리 형식 ϕ(X)
    uint64_t Z[4];                                                                     // 사영좌표계의 점의 Z좌표의 몽고메리 형식 ϕ(Z)
} ProjPoint;

// ====================================================================
// [Step 1: 다중 정밀도 기본기]
// ====================================================================

uint64_t add_256(uint64_t* res, const uint64_t* a, const uint64_t* b) {
    uint64_t carry = 0;
    for (int i = 0; i < 4; i++) {
        uint64_t sum = a[i] + carry;
        uint64_t carry1 = (sum < carry);
        uint64_t total_sum = sum + b[i];
        uint64_t carry2 = (total_sum < b[i]);
        res[i] = total_sum;
        carry = carry1 | carry2;
    }
    return carry;
}

uint64_t sub_256(uint64_t* res, const uint64_t* a, const uint64_t* b) {
    uint64_t borrow = 0;
    for (int i = 0; i < 4; i++) {
        uint64_t diff = a[i] - borrow;
        uint64_t borrow1 = (a[i] < borrow);
        uint64_t total_diff = diff - b[i];
        uint64_t borrow2 = (diff < b[i]);
        res[i] = total_diff;
        borrow = borrow1 | borrow2;
    }
    return borrow;
}

void cswap_256(uint64_t swap_flag, uint64_t* a, uint64_t* b) {
    uint64_t mask = 0 - swap_flag;
    for (int i = 0; i < 4; i++) {
        uint64_t dummy = mask & (a[i] ^ b[i]);
        a[i] ^= dummy;
        b[i] ^= dummy;
    }
}

void cswap_point(uint64_t swap_flag, ProjPoint* p1, ProjPoint* p2) {
    cswap_256(swap_flag, p1->X, p2->X);
    cswap_256(swap_flag, p1->Z, p2->Z);
}

void copy_point(ProjPoint* dest, const ProjPoint* src) {
    for (int i = 0; i < 4; i++) {
        dest->X[i] = src->X[i];
        dest->Z[i] = src->Z[i];
    }
}

// ====================================================================
// [Step 2: 고속 모듈러 연산 세트]
// ====================================================================

uint64_t mac_64(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t* carry) {
    uint64_t high, low;
    low = _umul128(a, b, &high);
    low += c;
    high += (low < c);
    low += d;
    high += (low < d);
    *carry = high;
    return low;
}

void mod_add_256(uint64_t* res, const uint64_t* a, const uint64_t* b, const uint64_t* p) {
    uint64_t sum[4], diff[4];
    uint64_t carry = add_256(sum, a, b);
    uint64_t borrow = sub_256(diff, sum, p);
    uint64_t mask = 0 - ((~carry & borrow) & 1);
    for (int i = 0; i < 4; i++) { res[i] = (sum[i] & mask) | (diff[i] & ~mask); }
}

void mod_sub_256(uint64_t* res, const uint64_t* a, const uint64_t* b, const uint64_t* p) {
    uint64_t diff[4], sum[4];
    uint64_t borrow = sub_256(diff, a, b);
    add_256(sum, diff, p);
    uint64_t mask = 0 - borrow;
    for (int i = 0; i < 4; i++) {
        res[i] = (sum[i] & mask) | (diff[i] & ~mask);
    }
}

void mont_mul_256(uint64_t* res, const uint64_t* a, const uint64_t* b, const uint64_t* p) {
    uint64_t t[5] = { 0 };
    uint64_t carry = 0;
    for (int i = 0; i < 4; i++) {
        carry = 0;
        for (int j = 0; j < 4; j++)
            t[j] = mac_64(a[i], b[j], t[j], carry, &carry);
        t[4] += carry;

        uint64_t m = t[0] * M0;
        carry = 0;
        mac_64(m, p[0], t[0], carry, &carry);

        for (int j = 1; j < 4; j++)
            t[j - 1] = mac_64(m, p[j], t[j], carry, &carry);

        uint64_t sum = t[4] + carry; t[3] = sum; t[4] = (sum < carry);
    }
    uint64_t temp[4];
    uint64_t borrow = sub_256(temp, t, p);
    uint64_t mask = 0 - borrow;
    for (int i = 0; i < 4; i++)
        res[i] = (t[i] & mask) | (temp[i] & ~mask);
}

void to_montgomery(uint64_t* res, const uint64_t* a, const uint64_t* p) {
    mont_mul_256(res, a, R2_MOD_P, p);
}

void from_montgomery(uint64_t* res, const uint64_t* a_mont, const uint64_t* p) {
    mont_mul_256(res, a_mont, ONE, p);
}

void mod_inv_256(uint64_t* res, const uint64_t* a, const uint64_t* p) {
    uint64_t a_mont[4], r_mont[4] = { ONE_MONT[0], ONE_MONT[1], ONE_MONT[2], ONE_MONT[3] };
    to_montgomery(a_mont, a, p);
    for (int i = 254; i >= 0; i--) {
        mont_mul_256(r_mont, r_mont, r_mont, p);
        if (((P_MINUS_2[i / 64] >> (i % 64)) & 1) == 1) mont_mul_256(r_mont, r_mont, a_mont, p);
    }
    from_montgomery(res, r_mont, p);
}

// ====================================================================
// [Step 3: 타원곡선 점 연산]
// ====================================================================

void point_double(ProjPoint* res, const ProjPoint* pt, const uint64_t* p) {
    uint64_t t0[4], t1[4], U[4], V[4], Diff[4], temp[4];
    mod_add_256(t0, pt->X, pt->Z, p); mod_sub_256(t1, pt->X, pt->Z, p);
    mont_mul_256(U, t0, t0, p); mont_mul_256(V, t1, t1, p);
    mod_sub_256(Diff, U, V, p);
    mont_mul_256(res->X, U, V, p);
    mont_mul_256(temp, Diff, A24_MONT, p); mod_add_256(temp, V, temp, p);
    mont_mul_256(res->Z, Diff, temp, p);
}

void point_add(ProjPoint* res, const ProjPoint* P1, const ProjPoint* P2, const ProjPoint* P_diff, const uint64_t* p) {
    uint64_t t0[4], t1[4], A[4], B[4], sum_sq[4], diff_sq[4];
    mod_add_256(t0, P1->X, P1->Z, p); mod_sub_256(t1, P2->X, P2->Z, p); mont_mul_256(A, t0, t1, p);
    mod_sub_256(t0, P1->X, P1->Z, p); mod_add_256(t1, P2->X, P2->Z, p); mont_mul_256(B, t0, t1, p);
    mod_add_256(t0, A, B, p); mont_mul_256(sum_sq, t0, t0, p);
    mod_sub_256(t1, A, B, p); mont_mul_256(diff_sq, t1, t1, p);
    mont_mul_256(res->X, P_diff->Z, sum_sq, p); mont_mul_256(res->Z, P_diff->X, diff_sq, p);
}

// ====================================================================
// [Step 4: 몽고메리 사다리 메인 루프] 
// ====================================================================
void curve25519_scalar_mult(ProjPoint* res, const uint64_t* scalar, const uint64_t* base_x) {
    ProjPoint R0, R1;
    uint64_t k[4];

    for (int i = 0; i < 4; i++)
        k[i] = scalar[i];
    k[0] &= 0xFFFFFFFFFFFFFFF8ULL; k[3] &= 0x7FFFFFFFFFFFFFFFULL; k[3] |= 0x4000000000000000ULL;

    uint64_t zero[4] = { 0, 0, 0, 0 };
    to_montgomery(R0.X, ONE, P); to_montgomery(R0.Z, zero, P);
    to_montgomery(R1.X, base_x, P); to_montgomery(R1.Z, ONE, P);

    ProjPoint P_diff; copy_point(&P_diff, &R1);

    uint64_t prev_bit = 0;
    for (int i = 254; i >= 0; i--) {
        uint64_t bit = (k[i / 64] >> (i % 64)) & 1;
        uint64_t swap = bit ^ prev_bit;
        cswap_point(swap, &R0, &R1);

        ProjPoint next_R0, next_R1;
        point_add(&next_R1, &R0, &R1, &P_diff, P);
        point_double(&next_R0, &R0, P);

        copy_point(&R0, &next_R0); copy_point(&R1, &next_R1);
        prev_bit = bit;
    }
    cswap_point(prev_bit, &R0, &R1);
    copy_point(res, &R0);
}

// ====================================================================
// [Step 5: 최종 좌표 변환 (Affine X)] 
// ====================================================================
void get_affine_x(uint64_t* affine_x, const ProjPoint* pt_mont, const uint64_t* p) {
    uint64_t z_norm[4], z_inv[4];
    from_montgomery(z_norm, pt_mont->Z, p);
    mod_inv_256(z_inv, z_norm, p);
    mont_mul_256(affine_x, pt_mont->X, z_inv, p);
}

// 결과 출력 편의 함수
void print_256(const char* name, const uint64_t* num) {
    printf("%s:\n%016llx %016llx %016llx %016llx\n", name, num[3], num[2], num[1], num[0]);
}

// ====================================================================
// [메인 함수] Curve25519 테스트 (다중 스칼라 및 CPU 사이클 측정)
// ====================================================================
int main() {
    printf("=== Curve25519 Montgomery Ladder 성능 테스트 실험 ===\n\n");

    // 1. 기준점 X (표준 값 9)                                                                           
    uint64_t Base_X[4] = { 9, 0, 0, 0 };

    // 2-2. 사용자의 256비트 비밀키 (모든 비트가 1인 케이스)
    uint64_t Private_Key_All_Ones[4] = { 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL };

    // 2-3. 사용자의 256비트 비밀키 (모든 비트가 0인 케이스)
    uint64_t Private_Key_All_Zeros[4] = { 0, 0, 0, 0 };

    ProjPoint Projective_Result;
    uint64_t Final_Affine_X[4];

    uint64_t start_cycle, end_cycle;

    // 반복 측정을 위한 횟수 상수 정의
    const int TEST1_SCALARS = 100;
    const int TEST23_ITERATIONS = 1000;

    printf("[Base Point (Affine X Coordinate)]\n");
    print_256("Base_X", Base_X);
    printf("\n");


    // ==========================================================
    // [테스트 1 - 랜덤 case] 무작위 256비트 스칼라 100개 평균 측정 (Average Case)
    // ==========================================================
    printf("--- Test 1 : 100 Random Scalars (Average Case) ---\n");
    uint64_t sum_cycles_test1 = 0;

    for (int iter = 0; iter < TEST1_SCALARS; iter++) {
        start_cycle = __rdtsc();
        // 헤더 파일(test_vectors.h)의 Random_Scalars[iter] 배열을 차례로 대입
        curve25519_scalar_mult(&Projective_Result, Random_Scalars[iter], Base_X);
        end_cycle = __rdtsc();
        sum_cycles_test1 += (end_cycle - start_cycle);
    }

    // 통계 신뢰도 확보 및 검증을 위해 마지막 100번째 연산의 아핀 결과 좌표만 1회 복원 출력
    get_affine_x(Final_Affine_X, &Projective_Result, P);
    print_256("Result_1 (100th run)", Final_Affine_X);
    printf("-> Average CPU Cycles (100 runs): %llu\n\n", sum_cycles_test1 / TEST1_SCALARS);


    // ==========================================================
    // [테스트 2 - 최악의 case] 모든 비트가 1인 키 스칼라 곱셈 (1,000번 반복 평균)
    // ==========================================================
    printf("--- Test 2 : All Bits are 1 (1,000 Iterations) ---\n");
    uint64_t sum_cycles_test2 = 0;

    for (int iter = 0; iter < TEST23_ITERATIONS; iter++) {
        start_cycle = __rdtsc();
        curve25519_scalar_mult(&Projective_Result, Private_Key_All_Ones, Base_X);
        end_cycle = __rdtsc();
        sum_cycles_test2 += (end_cycle - start_cycle);
    }

    get_affine_x(Final_Affine_X, &Projective_Result, P);
    print_256("Result_2", Final_Affine_X);
    printf("-> Average CPU Cycles (1,000 runs): %llu\n\n", sum_cycles_test2 / TEST23_ITERATIONS);


    // ==========================================================
    // [테스트 3 - 최선의 case] 모든 비트가 0인 키 스칼라 곱셈 (1,000번 반복 평균)
    // ==========================================================
    printf("--- Test 3 : All Bits are 0 (1,000 Iterations) ---\n");
    uint64_t sum_cycles_test3 = 0;

    for (int iter = 0; iter < TEST23_ITERATIONS; iter++) {
        start_cycle = __rdtsc();
        curve25519_scalar_mult(&Projective_Result, Private_Key_All_Zeros, Base_X);
        end_cycle = __rdtsc();
        sum_cycles_test3 += (end_cycle - start_cycle);
    }

    get_affine_x(Final_Affine_X, &Projective_Result, P);
    print_256("Result_3", Final_Affine_X);
    printf("-> Average CPU Cycles (1,000 runs): %llu\n\n", sum_cycles_test3 / TEST23_ITERATIONS);

    // 5. 완료.
    printf("-> Project Complete! The ECC core is fully functional.\n");

    return 0;
}